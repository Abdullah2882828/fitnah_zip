# Architecture

## Web
- Next.js App Router
- React 19
- Tailwind CSS 4
- Client components for the workspace and settings
- API Route Handlers for OAuth, provider validation, chat, and GitHub sync

## Authentication
`/api/auth/github/start` -> GitHub authorization -> `/api/auth/github/callback` -> encrypted JWT session cookie -> `/api/auth/me`.

The session token is HttpOnly and is never exposed to React. GitHub OAuth uses a state cookie to mitigate CSRF. The requested scope is configurable with `GITHUB_OAUTH_SCOPE`.

## Provider layer
`/api/providers/validate` recognizes:
- Groq: `GET https://api.groq.com/openai/v1/models`
- Gemini: `GET https://generativelanguage.googleapis.com/v1beta/models`
- DeepSeek: `GET https://api.deepseek.com/models`
- Claude: a minimal authenticated Messages request
- Custom OpenAI-compatible: `${baseUrl}/models`

`/api/ai/chat` normalizes chat into provider-specific payloads.

## Local API-key vault
The browser generates a non-extractable AES-GCM key using Web Crypto and stores it in IndexedDB. Provider keys are encrypted before storage. The server does not write provider keys to disk.

## Preview
The current renderer accepts an `index.html` plus CSS/JS/project files and creates an iframe sandbox preview. It is intentionally framework-agnostic at this layer. A future production bundler can replace `makeHtml()` with a worker-based bundling pipeline without changing the rest of the UI.

## GitHub sync
1. Create repository with `POST /user/repos`.
2. Create one blob per project file.
3. Create one tree.
4. Create one commit.
5. Create/update `main`.

This avoids serial one-file commits and is better for multi-file projects.
