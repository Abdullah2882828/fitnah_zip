# الفطنة — Al-Fitnah

AI workspace for chat, code generation, live preview, and GitHub publishing.

## What is included

- Arabic RTL-first light UI.
- Provided الفطنة logo wired into the app icon, sidebar, and header.
- GitHub OAuth login with a persistent HttpOnly session cookie.
- Provider manager for Groq, Gemini, DeepSeek, Claude, and unlimited custom OpenAI-compatible providers.
- Local browser vault for API keys using Web Crypto + IndexedDB. Keys are not saved on the server.
- Provider connection status: connected, failed, or provider needs balance/rate-limit recovery.
- AI chat with active-provider dropdown, attachments, saved bubbles, and build-intent preview activation.
- Live preview that can render a generated multi-file web project as an in-browser HTML preview.
- GitHub repository creation + multi-file sync using GitHub Git Database APIs.
- Website sync is forced Public; app sync can be Public or Private.

## Important production note

The app does not impose an artificial file-count or file-size cap in its UI. Browser memory, the hosting runtime, GitHub API limits, and repository limits still apply. Very large projects should eventually use streamed object uploads or Git LFS where appropriate.

## Setup

1. Create a GitHub OAuth App. Set the callback URL to `${APP_URL}/api/auth/github/callback`.
2. Set `GITHUB_CLIENT_ID`, `GITHUB_CLIENT_SECRET`, `SESSION_SECRET`, and `APP_URL` in `.env.local`.
3. Install dependencies and run `npm run dev`.
4. Open `http://localhost:3000` and continue with GitHub.

## OAuth scopes

This template requests `repo workflow` because repository creation and private repository writes require repository permissions, and workflows need the additional workflow permission. Review the scope shown in GitHub before authorizing.

## Security model

- GitHub tokens stay in an encrypted, HttpOnly cookie and are never sent to the browser JavaScript runtime.
- Provider API keys are stored locally in an IndexedDB vault encrypted with an AES-GCM Web Crypto key.
- Provider API keys are sent to the app server only for the specific validation/chat operation and are not persisted server-side.
- Do not deploy without HTTPS in production.
