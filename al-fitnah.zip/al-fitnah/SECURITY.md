# Security notes

- Never put `GITHUB_CLIENT_SECRET`, `SESSION_SECRET`, or server-side GitHub access tokens in client code.
- Keep provider API keys in the browser vault and send them only to trusted API routes.
- Use HTTPS in production.
- Limit the GitHub OAuth callback to an exact registered URL.
- Review GitHub scopes before users authorize the application.
- Do not log provider keys, GitHub access tokens, prompts containing secrets, or full request bodies.
- The preview iframe uses `sandbox="allow-scripts"`; do not add `allow-same-origin` unless you have a clear isolation model.
