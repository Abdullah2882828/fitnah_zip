import { NextResponse } from "next/server";

type Body = {
  kind: string;
  apiKey: string;
  baseUrl?: string;
  model: string;
  messages: Array<{ role: "user" | "assistant" | "system"; content: string }>;
};

function error(res: number, message: string) { return NextResponse.json({ error: message }, { status: res }); }

export async function POST(request: Request) {
  let body: Body;
  try { body = await request.json(); } catch { return error(400, "طلب غير صالح"); }
  if (!body.apiKey || !body.model || !Array.isArray(body.messages)) return error(400, "بيانات المزود أو الرسائل ناقصة");

  try {
    let response: Response;

    if (body.kind === "gemini") {
      const contents = body.messages.filter(m => m.role !== "system").map(m => ({
        role: m.role === "assistant" ? "model" : "user",
        parts: [{ text: m.content }]
      }));
      response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(body.model)}:generateContent?key=${encodeURIComponent(body.apiKey)}`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ contents, systemInstruction: body.messages.find(m => m.role === "system") ? { parts: [{ text: body.messages.find(m => m.role === "system")?.content }] } : undefined })
      });
    } else if (body.kind === "anthropic") {
      response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "content-type": "application/json", "x-api-key": body.apiKey, "anthropic-version": "2023-06-01" },
        body: JSON.stringify({ model: body.model, max_tokens: 4096, messages: body.messages.filter(m => m.role !== "system") })
      });
    } else {
      const base = body.kind === "groq" ? "https://api.groq.com/openai/v1" : body.kind === "deepseek" ? "https://api.deepseek.com" : (body.baseUrl || "").replace(/\/$/, "");
      response = await fetch(`${base}/chat/completions`, {
        method: "POST",
        headers: { "content-type": "application/json", authorization: `Bearer ${body.apiKey}` },
        body: JSON.stringify({ model: body.model, messages: body.messages, stream: false })
      });
    }

    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const needsBalance = response.status === 402 || response.status === 429;
      return NextResponse.json({ error: needsBalance ? "رفض المزود يحتاج إلى رصيد أو توجد حدود استخدام" : (data?.error?.message || data?.message || "فشل طلب الذكاء الاصطناعي") }, { status: response.status });
    }

    const text = body.kind === "gemini"
      ? data?.candidates?.[0]?.content?.parts?.map((p: { text?: string }) => p.text || "").join("") || ""
      : body.kind === "anthropic"
        ? data?.content?.filter((x: { type?: string }) => x.type === "text").map((x: { text?: string }) => x.text || "").join("") || ""
        : data?.choices?.[0]?.message?.content || "";

    return NextResponse.json({ text });
  } catch (e) {
    return error(502, e instanceof Error ? e.message : "تعذر الاتصال بالمزود");
  }
}
