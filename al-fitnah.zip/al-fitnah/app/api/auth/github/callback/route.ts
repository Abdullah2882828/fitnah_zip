import { NextRequest, NextResponse } from "next/server";
import { githubMe } from "@/lib/github";
import { setSession } from "@/lib/session";

export async function GET(request: NextRequest) {
  const code = request.nextUrl.searchParams.get("code");
  const state = request.nextUrl.searchParams.get("state");
  const savedState = request.cookies.get("al_fitnah_oauth_state")?.value;
  const appUrl = process.env.APP_URL || "http://localhost:3000";

  if (!code || !state || !savedState || state !== savedState) {
    return NextResponse.redirect(`${appUrl}/?auth=error&reason=state`);
  }

  const body = new URLSearchParams({
    client_id: process.env.GITHUB_CLIENT_ID || "",
    client_secret: process.env.GITHUB_CLIENT_SECRET || "",
    code,
    redirect_uri: `${appUrl.replace(/\/$/, "")}/api/auth/github/callback`
  });

  const tokenRes = await fetch("https://github.com/login/oauth/access_token", {
    method: "POST",
    headers: { accept: "application/json", "content-type": "application/x-www-form-urlencoded" },
    body
  });
  const tokenData = await tokenRes.json();
  if (!tokenRes.ok || !tokenData.access_token) {
    return NextResponse.redirect(`${appUrl}/?auth=error&reason=token`);
  }

  try {
    const me = await githubMe(tokenData.access_token);
    await setSession({
      accessToken: tokenData.access_token,
      login: me.login,
      avatarUrl: me.avatar_url,
      name: me.name
    });
    const response = NextResponse.redirect(`${appUrl}/?auth=success`);
    response.cookies.delete("al_fitnah_oauth_state");
    return response;
  } catch {
    return NextResponse.redirect(`${appUrl}/?auth=error&reason=github`);
  }
}
