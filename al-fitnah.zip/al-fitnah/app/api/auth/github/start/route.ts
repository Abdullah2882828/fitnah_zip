import { NextResponse } from "next/server";
import crypto from "node:crypto";

export async function GET() {
  const clientId = process.env.GITHUB_CLIENT_ID;
  const appUrl = process.env.APP_URL || "http://localhost:3000";
  const scope = process.env.GITHUB_OAUTH_SCOPE || "repo workflow";
  if (!clientId) return NextResponse.json({ error: "GITHUB_CLIENT_ID is not configured" }, { status: 500 });

  const state = crypto.randomBytes(32).toString("hex");
  const callback = `${appUrl.replace(/\/$/, "")}/api/auth/github/callback`;
  const url = new URL("https://github.com/login/oauth/authorize");
  url.searchParams.set("client_id", clientId);
  url.searchParams.set("redirect_uri", callback);
  url.searchParams.set("scope", scope);
  url.searchParams.set("state", state);

  const res = NextResponse.redirect(url);
  res.cookies.set("al_fitnah_oauth_state", state, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 10 * 60
  });
  return res;
}
