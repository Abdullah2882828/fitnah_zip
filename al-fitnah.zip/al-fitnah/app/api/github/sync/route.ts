import { NextResponse } from "next/server";
import { getSession } from "@/lib/session";
import { createUserRepo, createBlob, createTree, createCommit, getRef, getCommit, updateRef } from "@/lib/github";

type Body = {
  name: string;
  description?: string;
  kind: "app" | "website";
  private: boolean;
  files: Array<{ path: string; content: string }>;
};

function safeRepoName(input: string) {
  return input.trim().replace(/[^a-zA-Z0-9._-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 100);
}

export async function POST(request: Request) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "GitHub login required" }, { status: 401 });

  let body: Body;
  try { body = await request.json(); } catch { return NextResponse.json({ error: "طلب غير صالح" }, { status: 400 }); }
  const name = safeRepoName(body.name);
  if (!name) return NextResponse.json({ error: "اسم المستودع غير صالح" }, { status: 400 });
  if (!Array.isArray(body.files) || body.files.length === 0) return NextResponse.json({ error: "لا توجد ملفات للمزامنة" }, { status: 400 });
  const privateRepo = body.kind === "website" ? false : Boolean(body.private);

  try {
    const repo = await createUserRepo(session.accessToken, { name, description: body.description, private: privateRepo });
    const owner = repo.owner.login;

    // For a newly-created empty repository, main may not exist yet. Create blobs first,
    // create a tree without a base tree, then commit it, then create/update the main ref.
    const treeItems = [] as Array<{ path: string; mode: string; type: string; sha: string }>;
    for (const file of body.files) {
      if (!file.path || file.path.startsWith("/") || file.path.includes("..")) continue;
      const blob = await createBlob(session.accessToken, owner, name, file.content || "");
      treeItems.push({ path: file.path.replace(/^\.\//, ""), mode: "100644", type: "blob", sha: blob.sha });
    }

    const tree = await createTree(session.accessToken, owner, name, null, treeItems);
    const commit = await createCommit(session.accessToken, owner, name, "feat: publish project from الفطنة", tree.sha, []);

    try {
      await updateRef(session.accessToken, owner, name, "heads/main", commit.sha);
    } catch {
      // Some newly created repositories do not have refs yet; create it through the raw Git API.
      const r = await fetch(`https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/git/refs`, {
        method: "POST",
        headers: {
          accept: "application/vnd.github+json",
          authorization: `Bearer ${session.accessToken}`,
          "X-GitHub-Api-Version": "2026-03-10",
          "content-type": "application/json"
        },
        body: JSON.stringify({ ref: "refs/heads/main", sha: commit.sha })
      });
      if (!r.ok) throw new Error((await r.json().catch(() => ({})))?.message || `فشل إنشاء main (${r.status})`);
    }

    return NextResponse.json({ ok: true, url: repo.html_url, fullName: repo.full_name, private: privateRepo });
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : "فشلت المزامنة" }, { status: 502 });
  }
}
