import { NextResponse } from "next/server";

type Body = { kind: string; apiKey: string; baseUrl?: string };

function providerResult(status: number, message: string, state: "connected" | "failed" | "needs_balance") {
  return NextResponse.json({ status: state, message }, { status });
}

export async function POST(request: Request) {
  let body: Body;
  try { body = await request.json(); } catch { return providerResult(400, "طلب غير صالح", "failed"); }
  const key = body.apiKey?.trim();
  if (!key) return providerResult(400, "المفتاح فارغ", "failed");

  try {
    if (body.kind === "groq") {
      const r = await fetch("https://api.groq.com/openai/v1/models", { headers: { authorization: `Bearer ${key}` }, cache: "no-store" });
      if (r.status === 401) return providerResult(401, "مفتاح غير صالح", "failed");
      if (r.status === 402 || r.status === 429) return providerResult(r.status, "رفض المزود يحتاج إلى رصيد أو توجد حدود استخدام", "needs_balance");
      if (!r.ok) return providerResult(r.status, "فشل الاتصال بـ Groq", "failed");
      return providerResult(200, "متصل ✅", "connected");
    }

    if (body.kind === "gemini") {
      const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${encodeURIComponent(key)}&pageSize=1`, { cache: "no-store" });
      if (r.status === 400 || r.status === 401 || r.status === 403) return providerResult(r.status, "مفتاح Gemini غير صالح أو مرفوض", "failed");
      if (r.status === 429) return providerResult(r.status, "رفض المزود يحتاج إلى رصيد أو توجد حدود استخدام", "needs_balance");
      if (!r.ok) return providerResult(r.status, "فشل الاتصال بـ Gemini", "failed");
      return providerResult(200, "متصل ✅", "connected");
    }

    if (body.kind === "deepseek") {
      const r = await fetch("https://api.deepseek.com/models", { headers: { authorization: `Bearer ${key}` }, cache: "no-store" });
      if (r.status === 401) return providerResult(401, "مفتاح غير صالح", "failed");
      if (r.status === 402 || r.status === 429) return providerResult(r.status, "رفض المزود يحتاج إلى رصيد أو توجد حدود استخدام", "needs_balance");
      if (!r.ok) return providerResult(r.status, "فشل الاتصال بـ DeepSeek", "failed");
      return providerResult(200, "متصل ✅", "connected");
    }

    if (body.kind === "anthropic") {
      const base = "https://api.anthropic.com";
      const r = await fetch(`${base}/v1/messages`, {
        method: "POST",
        headers: { "content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01" },
        body: JSON.stringify({ model: "claude-haiku-4-5-20251001", max_tokens: 1, messages: [{ role: "user", content: "ping" }] }),
        cache: "no-store"
      });
      if (r.status === 401) return providerResult(401, "مفتاح Claude غير صالح", "failed");
      if (r.status === 402 || r.status === 429) return providerResult(r.status, "رفض المزود يحتاج إلى رصيد أو توجد حدود استخدام", "needs_balance");
      if (r.status >= 200 && r.status < 300) return providerResult(200, "متصل ✅", "connected");
      return providerResult(r.status, "فشل الاتصال بـ Claude", "failed");
    }

    const base = (body.baseUrl || "").replace(/\/$/, "");
    if (!base) return providerResult(400, "ضع Base URL للمزود المخصص", "failed");
    const r = await fetch(`${base}/models`, { headers: { authorization: `Bearer ${key}` }, cache: "no-store" });
    if (r.status === 401) return providerResult(401, "مفتاح غير صالح", "failed");
    if (r.status === 402 || r.status === 429) return providerResult(r.status, "رفض المزود يحتاج إلى رصيد أو توجد حدود استخدام", "needs_balance");
    if (!r.ok) return providerResult(r.status, "فشل التحقق من المزود المخصص", "failed");
    return providerResult(200, "متصل ✅", "connected");
  } catch (error) {
    return providerResult(502, error instanceof Error ? error.message : "تعذر الوصول للمزود", "failed");
  }
}
