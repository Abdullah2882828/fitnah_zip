import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "الفطنة — AI Builder",
  description: "منصة الفطنة للدردشة والبرمجة وبناء التطبيقات والنشر إلى GitHub",
  icons: { icon: "/logo.png" }
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="ar" dir="rtl"><body>{children}</body></html>;
}
