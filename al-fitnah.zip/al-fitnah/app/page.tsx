"use client";

import { useEffect, useState } from "react";
import { LoginScreen } from "@/components/LoginScreen";
import { ChatWorkspace } from "@/components/ChatWorkspace";

export default function Home() {
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<{ login: string; name?: string | null; avatarUrl?: string | null } | null>(null);

  useEffect(() => {
    fetch("/api/auth/me", { cache: "no-store" }).then(r => r.json()).then(data => setUser(data.user || null)).finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="grid min-h-screen place-items-center bg-slate-50"><div className="h-10 w-10 animate-spin rounded-full border-4 border-slate-200 border-t-blue-600" /></div>;
  if (!user) return <LoginScreen />;
  return <ChatWorkspace user={user} />;
}
