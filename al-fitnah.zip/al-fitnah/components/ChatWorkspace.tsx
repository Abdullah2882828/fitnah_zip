"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { ChatMessage, ProjectFile } from "@/types";
import { SettingsPanel } from "./SettingsPanel";
import { GitHubSyncModal } from "./GitHubSyncModal";
import { PreviewPane } from "./PreviewPane";
import { Logo } from "./Logo";
import { readSecret } from "./Vault";

type ProviderRow = { id: string; name: string; kind: any; defaultModel?: string; baseUrl?: string; status: string; key?: string; note?: string };

const initialMessages: ChatMessage[] = [
  { id: "welcome", role: "assistant", text: "مرحباً بك في الفطنة. اكتب سؤالك، اطلب كوداً، أو قل لي ابنِ موقعاً/تطبيقاً وسأفتح لك المعاينة الحية تلقائياً.", timestamp: Date.now() }
];

function looksLikeBuild(text: string) { return /(ابن|بناء|أنشئ|اصنع|سوي|سوّي|website|web app|application|تطبيق|موقع)/i.test(text); }

export function ChatWorkspace({ user }: { user: { login: string; name?: string | null; avatarUrl?: string | null } }) {
  const [messages, setMessages] = useState<ChatMessage[]>(initialMessages);
  const [draft, setDraft] = useState("");
  const [attachments, setAttachments] = useState<File[]>([]);
  const [showSettings, setShowSettings] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [showSync, setShowSync] = useState(false);
  const [projectKind, setProjectKind] = useState<"app" | "website">("website");
  const [providers, setProviders] = useState<ProviderRow[]>([]);
  const [activeId, setActiveId] = useState("groq");
  const [files, setFiles] = useState<ProjectFile[]>([{ path: "index.html", content: "<!doctype html><html><body><main style='font-family:sans-serif;padding:48px'><h1>الفطنة</h1><p>ابدأ ببناء مشروعك من المحادثة.</p></main></body></html>" }]);
  const endRef = useRef<HTMLDivElement>(null);
  const active = useMemo(() => providers.find(p => p.id === activeId) || providers[0], [providers, activeId]);

  useEffect(() => endRef.current?.scrollIntoView({ behavior: "smooth" }), [messages]);

  const loadProviders = async (next?: ProviderRow[]) => {
    const source = next || [];
    const enriched = await Promise.all(source.map(async p => ({ ...p, key: p.key || await readSecret(p.id) })));
    setProviders(enriched);
    const connected = enriched.find(p => p.status === "connected");
    if (connected) setActiveId(connected.id);
  };

  const send = async () => {
    const text = draft.trim();
    if (!text) return;
    const build = looksLikeBuild(text);
    if (build) { setShowPreview(true); setProjectKind(/تطبيق|application|app/i.test(text) ? "app" : "website"); }
    const userMsg: ChatMessage = { id: crypto.randomUUID(), role: "user", text, timestamp: Date.now(), attachmentNames: attachments.map(f => f.name) };
    setMessages(old => [...old, userMsg]); setDraft(""); setAttachments([]);

    if (!active || active.status !== "connected") {
      setMessages(old => [...old, { id: crypto.randomUUID(), role: "assistant", text: "اختر مزوداً متصلاً من القائمة أو افتح الإعدادات وأضف مفتاح API ثم اضغط حفظ واتصال.", timestamp: Date.now() }]);
      return;
    }

    setMessages(old => [...old, { id: "typing", role: "assistant", text: "…", timestamp: Date.now() }]);
    try {
      const history = [...messages, userMsg].map(m => ({ role: m.role, content: m.text }));
      const r = await fetch("/api/ai/chat", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ kind: active.kind, apiKey: active.key, baseUrl: active.baseUrl, model: active.defaultModel, messages: history }) });
      const data = await r.json().catch(() => ({}));
      const reply = r.ok ? (data.text || "تمت الإجابة بدون نص.") : (data.error || "حدث خطأ في المزود.");
      setMessages(old => old.filter(m => m.id !== "typing").concat({ id: crypto.randomUUID(), role: "assistant", text: reply, timestamp: Date.now() }));
      if (build) {
        const generated = `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>مشروع الفطنة</title><style>body{margin:0;font-family:Arial;background:#f7f9fc;color:#172033}main{min-height:100vh;display:grid;place-items:center;padding:32px}.card{max-width:720px;background:#fff;border:1px solid #e8ecf2;border-radius:28px;padding:40px;box-shadow:0 18px 60px rgba(31,41,55,.08)}button{border:0;border-radius:14px;padding:12px 18px;background:#1867ff;color:#fff;font-weight:700}</style></head><body><main><section class="card"><h1>مشروع جديد</h1><p>${text.replace(/</g,"&lt;")}</p><button>ابدأ الآن</button></section></main></body></html>`;
        setFiles([{ path: "index.html", content: generated }]);
      }
    } catch (e) {
      setMessages(old => old.filter(m => m.id !== "typing").concat({ id: crypto.randomUUID(), role: "assistant", text: e instanceof Error ? e.message : "تعذر إكمال الطلب.", timestamp: Date.now() }));
    }
  };

  const logout = async () => { await fetch("/api/auth/logout", { method: "POST" }); location.reload(); };

  return <div className="flex h-screen min-h-0 flex-col bg-[#f7f9fc]">
    <header className="flex h-16 shrink-0 items-center justify-between gap-4 border-b border-slate-200 bg-white/90 px-3 backdrop-blur sm:px-5">
      <div className="flex min-w-0 items-center gap-3"><Logo compact /><div className="hidden sm:block"><div className="font-black">الفطنة</div><div className="text-[10px] text-slate-400">Ask • Build • Publish</div></div></div>
      <div className="flex items-center gap-2"><div className="hidden items-center gap-2 rounded-2xl border border-slate-200 bg-white px-3 py-2 text-xs sm:flex"><span className="h-2 w-2 rounded-full bg-emerald-500"/> {user.name || user.login}</div><button onClick={() => setShowSettings(true)} className="rounded-2xl border border-slate-200 bg-white px-3 py-2 text-sm font-bold">الإعدادات</button><button onClick={logout} className="rounded-2xl px-3 py-2 text-sm text-slate-500">خروج</button></div>
    </header>

    <div className="grid min-h-0 flex-1 lg:grid-cols-[260px_minmax(0,1fr)_minmax(360px,42%)]">
      <aside className="desktop-only min-h-0 overflow-y-auto border-l border-slate-200 bg-white p-4">
        <div className="rounded-3xl bg-slate-50 p-4"><div className="text-xs font-bold text-slate-400">الحساب</div><div className="mt-2 font-black">@{user.login}</div><div className="mt-1 text-xs text-slate-500">جلسة GitHub محفوظة</div></div>
        <div className="mt-5 text-xs font-bold text-slate-400">مشروع العمل</div><div className="mt-2 rounded-3xl border border-blue-100 bg-blue-50 p-4"><div className="font-black text-blue-950">مشروع جديد</div><div className="mt-1 text-xs leading-5 text-blue-800">اكتب طلبك وسيتم فتح المعاينة عند اكتشاف نية البناء.</div></div>
      </aside>

      <main className="min-h-0 min-w-0 bg-white">
        <div className="app-scroll h-full overflow-y-auto">
          <div className="mx-auto max-w-4xl px-4 py-6 sm:px-8 sm:py-8">
            <div className="mb-6 text-center"><h1 className="text-2xl font-black sm:text-3xl">ماذا تريد أن تبني اليوم؟</h1><p className="mt-2 text-sm text-slate-500">دردشة، كود، موقع، تطبيق — الفطنة تجمعها في مساحة واحدة.</p></div>
            <div className="overflow-hidden rounded-[28px] border border-slate-200 bg-slate-50/70">
              {messages.map((m, idx) => <div key={m.id} className={`border-b border-slate-200/80 px-4 py-5 sm:px-6 ${m.role === "user" ? "bg-white" : "bg-slate-50/40"}`}><div className="flex gap-3"><div className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-2xl text-xs font-black ${m.role === "user" ? "bg-slate-900 text-white" : "bg-blue-100 text-blue-800"}`}>{m.role === "user" ? "أنت" : "ف"}</div><div className="min-w-0 flex-1"><div className="mb-1 text-xs font-bold text-slate-400">{m.role === "user" ? "رسالتك" : "الفطنة AI"}</div><div className="whitespace-pre-wrap text-sm leading-7 text-slate-800">{m.text}</div>{m.attachmentNames?.length ? <div className="mt-3 flex flex-wrap gap-2">{m.attachmentNames.map(n => <span key={n} className="rounded-xl bg-slate-100 px-3 py-1 text-xs text-slate-600">📎 {n}</span>)}</div> : null}</div></div></div>)}
              <div ref={endRef} />
            </div>
          </div>
        </div>
        <div className="border-t border-slate-200 bg-white p-3 sm:p-4">
          <div className="mx-auto max-w-4xl">
            <div className="mb-2 flex items-center justify-between gap-2"><label className="flex items-center gap-2 text-xs font-bold text-slate-500"><span>النموذج النشط</span><select value={activeId} onChange={e => setActiveId(e.target.value)} className="rounded-xl border border-slate-200 bg-white px-2 py-1.5 text-xs outline-none">{providers.length ? providers.map(p => <option key={p.id} value={p.id}>{p.name}{p.status === "connected" ? " ✅" : ""}</option>) : <option>لا يوجد مزود</option>}</select></label><button onClick={() => setShowPreview(true)} className="rounded-xl border border-slate-200 px-3 py-2 text-xs font-bold">المعاينة الحية</button></div>
            <div className="rounded-[24px] border border-slate-200 bg-white shadow-[0_10px_40px_rgba(31,41,55,.06)]"><textarea value={draft} onChange={e => setDraft(e.target.value)} onKeyDown={e => { if ((e.ctrlKey || e.metaKey) && e.key === "Enter") send(); }} placeholder="اكتب طلبك… مثال: ابنِ صفحة متجر عربية حديثة" className="min-h-28 w-full resize-none rounded-[24px] px-4 py-4 text-sm outline-none" /><div className="flex items-center justify-between gap-3 px-3 pb-3"><div className="flex items-center gap-2"><label className="flex h-10 w-10 items-center justify-center rounded-2xl border border-slate-200 bg-slate-50 font-black text-slate-700" title="مرفق"><input type="file" multiple className="hidden" onChange={e => setAttachments(Array.from(e.target.files || []))} />+</label><span className="text-xs text-slate-400">{attachments.length ? `${attachments.length} مرفق` : "صورة أو ملف"}</span></div><button onClick={send} className="rounded-2xl bg-blue-600 px-5 py-3 text-sm font-black text-white shadow-lg shadow-blue-600/20">إرسال ↗</button></div></div>
          </div>
        </div>
      </main>

      {showPreview && <div className="hidden min-h-0 lg:block"><PreviewPane files={files} projectTitle={projectKind === "website" ? "مشروع موقع" : "مشروع تطبيق"} onClose={() => setShowPreview(false)} onSync={() => setShowSync(true)} /></div>}
      {!showPreview && <aside className="desktop-only border-r border-slate-200 bg-white p-6"><div className="rounded-[28px] border border-dashed border-slate-300 p-6 text-center"><div className="text-4xl">✦</div><div className="mt-3 font-black">المعاينة الحية</div><div className="mt-2 text-xs leading-6 text-slate-500">ستظهر تلقائياً عندما تطلب بناء موقع أو تطبيق.</div></div></aside>}
    </div>

    {showSettings && <SettingsPanel onClose={() => setShowSettings(false)} onProvidersChange={p => loadProviders(p)} />}
    {showSync && <GitHubSyncModal kind={projectKind} files={files} onClose={() => setShowSync(false)} />}
  </div>;
}
