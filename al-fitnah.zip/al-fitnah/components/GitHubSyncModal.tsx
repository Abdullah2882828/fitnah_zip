"use client";

import { useState } from "react";
import { ProjectFile } from "@/types";

export function GitHubSyncModal({ kind, files, onClose }: { kind: "app" | "website"; files: ProjectFile[]; onClose: () => void }) {
  const [name, setName] = useState(kind === "website" ? "al-fitnah-website" : "al-fitnah-app");
  const [description, setDescription] = useState("");
  const [privateRepo, setPrivateRepo] = useState(kind === "app");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [url, setUrl] = useState("");

  const sync = async () => {
    setBusy(true); setError("");
    try {
      const r = await fetch("/api/github/sync", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ name, description, kind, private: kind === "website" ? false : privateRepo, files }) });
      const data = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(data.error || "فشلت المزامنة");
      setUrl(data.url);
    } catch (e) { setError(e instanceof Error ? e.message : "فشلت المزامنة"); } finally { setBusy(false); }
  };

  return <div className="fixed inset-0 z-[60] bg-slate-950/30 p-4 backdrop-blur-sm"><div className="mx-auto mt-16 max-w-xl rounded-[28px] border border-slate-200 bg-white p-6 shadow-2xl">
    <div className="flex items-start justify-between"><div><h3 className="text-xl font-black">متابعة التزامن مع GitHub</h3><p className="mt-1 text-xs text-slate-500">سيُنشأ مستودع جديد وتُرفع إليه ملفات المشروع.</p></div><button onClick={onClose} className="rounded-xl px-3 py-2 text-slate-500">✕</button></div>
    {!url ? <div className="mt-6 grid gap-4">
      <input value={name} onChange={e => setName(e.target.value)} placeholder="اسم المستودع الجديد" className="rounded-2xl border border-slate-200 px-4 py-3 outline-none focus:border-blue-500" dir="ltr" />
      <textarea value={description} onChange={e => setDescription(e.target.value)} placeholder="وصف المستودع" className="min-h-24 rounded-2xl border border-slate-200 px-4 py-3 outline-none focus:border-blue-500" />
      <div className="rounded-2xl bg-slate-50 p-4"><div className="mb-2 text-xs font-bold text-slate-500">نوع المستودع</div>{kind === "website" ? <div className="font-bold text-slate-900">عام (Public) — مفروض للمواقع</div> : <label className="flex items-center justify-between gap-3"><span className="font-bold">خاص (Private)</span><input type="checkbox" checked={privateRepo} onChange={e => setPrivateRepo(e.target.checked)} className="h-5 w-5" /></label>}</div>
      {error && <div className="rounded-2xl bg-rose-50 p-4 text-sm text-rose-700">{error}</div>}
      <button disabled={busy || !name.trim()} onClick={sync} className="rounded-2xl bg-slate-950 px-5 py-4 font-black text-white disabled:opacity-50">{busy ? "جاري النشر…" : "إنشاء المستودع ونشر المشروع"}</button>
    </div> : <div className="mt-6 rounded-2xl bg-emerald-50 p-5"><div className="font-black text-emerald-900">تمت المزامنة بنجاح ✅</div><a className="mt-3 block break-all text-sm text-emerald-700 underline" href={url} target="_blank" rel="noreferrer">{url}</a></div>}
  </div></div>;
}
