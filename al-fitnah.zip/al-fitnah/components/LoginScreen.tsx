"use client";

import { Logo } from "./Logo";

export function LoginScreen() {
  return (
    <main className="min-h-screen bg-[radial-gradient(circle_at_top,#ffffff_0%,#f2f6fc_55%,#edf2f8_100%)] px-5 py-10">
      <div className="mx-auto flex min-h-[calc(100vh-5rem)] max-w-xl items-center justify-center">
        <section className="glass soft-shadow w-full rounded-[32px] border border-slate-200/70 p-7 text-center sm:p-10">
          <div className="mb-7 flex justify-center"><Logo /></div>
          <h1 className="text-3xl font-black tracking-tight text-slate-950">أهلاً بك في الفطنة</h1>
          <p className="mx-auto mt-3 max-w-md text-sm leading-7 text-slate-500">منصة واحدة للدردشة مع النماذج، توليد الكود، بناء المواقع والتطبيقات، ومعاينتها ثم نشرها مباشرة إلى GitHub.</p>
          <a href="/api/auth/github/start" className="mt-8 flex items-center justify-center gap-3 rounded-2xl bg-slate-950 px-5 py-4 font-bold text-white shadow-lg shadow-slate-950/10 transition hover:-translate-y-0.5 hover:bg-slate-900">
            <span className="text-xl">◉</span> المتابعة بـ GitHub
          </a>
          <div className="mt-5 rounded-2xl bg-blue-50 px-4 py-3 text-xs leading-6 text-blue-800">عند تسجيل الدخول نطلب صلاحيات GitHub اللازمة لإنشاء المستودعات ومزامنة المشاريع التي تختار نشرها.</div>
        </section>
      </div>
    </main>
  );
}
