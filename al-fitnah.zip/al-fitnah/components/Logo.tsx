"use client";

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`flex items-center gap-3 ${compact ? "" : "min-w-0"}`}>
      <img src="/logo.png" alt="الفطنة" className={compact ? "h-9 w-9 rounded-xl object-cover" : "h-12 w-12 rounded-2xl object-cover shadow-sm"} />
      {!compact && <div className="min-w-0">
        <div className="truncate text-base font-black text-slate-900">الفطنة</div>
        <div className="truncate text-[11px] text-slate-500">ذكاء • برمجة • بناء</div>
      </div>}
    </div>
  );
}
