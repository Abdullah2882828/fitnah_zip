"use client";

import { useMemo } from "react";
import { ProjectFile } from "@/types";

function makeHtml(files: ProjectFile[]) {
  const html = files.find(f => /(^|\/)index\.html$/i.test(f.path))?.content;
  if (html) return html;
  const css = files.filter(f => f.path.endsWith(".css")).map(f => f.content).join("\n");
  const js = files.filter(f => f.path.endsWith(".js") || f.path.endsWith(".ts")).map(f => f.content).join("\n");
  const body = files.filter(f => !f.path.match(/\.(css|js|ts|json)$/i)).map(f => f.content).join("\n");
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>${css}</style></head><body>${body || "<main style='font-family:sans-serif;padding:40px'>لا توجد صفحة index.html بعد.</main>"}<script>${js}</script></body></html>`;
}

export function PreviewPane({ files, projectTitle, onClose, onSync }: { files: ProjectFile[]; projectTitle: string; onClose: () => void; onSync: () => void }) {
  const html = useMemo(() => makeHtml(files), [files]);
  return <aside className="flex h-full min-h-0 flex-col border-r border-slate-200 bg-white">
    <div className="flex items-center justify-between gap-3 border-b border-slate-100 px-4 py-3"><div><div className="text-sm font-black">المعاينة الحية</div><div className="text-[11px] text-slate-400">{projectTitle}</div></div><button onClick={onClose} className="rounded-xl px-3 py-2 text-sm text-slate-500">إغلاق ✕</button></div>
    <div className="min-h-0 flex-1 bg-slate-100 p-3"><iframe title="Live Preview" sandbox="allow-scripts" srcDoc={html} className="h-full w-full rounded-2xl border border-slate-200 bg-white shadow-sm" /></div>
    <div className="grid grid-cols-2 gap-2 border-t border-slate-100 p-3"><button onClick={() => new Blob([html], { type: "text/html;charset=utf-8" }) && (window.location.href = URL.createObjectURL(new Blob([html], { type: "text/html;charset=utf-8" })))} className="rounded-2xl border border-slate-200 bg-white px-3 py-3 text-xs font-bold">فتح المعاينة</button><button onClick={onSync} className="rounded-2xl bg-slate-950 px-3 py-3 text-xs font-black text-white">متابعة التزامن مع GitHub</button></div>
  </aside>;
}
