"use client";

import { useEffect, useState } from "react";
import { ProviderConfig, ProviderStatus } from "@/types";
import { readSecret, removeSecret, saveSecret } from "./Vault";

type ProviderRow = ProviderConfig & { status: ProviderStatus; note?: string };

const baseProviders: ProviderRow[] = [
  { id: "groq", name: "Groq", kind: "groq", defaultModel: "openai/gpt-oss-120b", status: "idle" },
  { id: "gemini", name: "Gemini", kind: "gemini", defaultModel: "gemini-3.8-flash", status: "idle" },
  { id: "deepseek", name: "DeepSeek", kind: "deepseek", defaultModel: "deepseek-flash", status: "idle" },
  { id: "anthropic", name: "Claude", kind: "anthropic", defaultModel: "claude-sonnet-4-6", status: "idle" }
];

export function SettingsPanel({ onClose, onProvidersChange }: { onClose: () => void; onProvidersChange: (p: ProviderRow[]) => void }) {
  const [section, setSection] = useState<"providers" | "account" | "about">("providers");
  const [providers, setProviders] = useState<ProviderRow[]>(baseProviders);
  const [openId, setOpenId] = useState("groq");

  useEffect(() => {
    (async () => {
      const next = await Promise.all(providers.map(async p => ({ ...p, key: undefined, note: (await readSecret(p.id)) ? "مفتاح محفوظ محلياً" : undefined })));
      setProviders(next);
      onProvidersChange(next);
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const update = (id: string, patch: Partial<ProviderRow>) => {
    setProviders(old => old.map(p => p.id === id ? { ...p, ...patch } : p));
  };

  const connect = async (p: ProviderRow) => {
    const key = (p.key || "").trim();
    if (!key) {
      update(p.id, { status: "failed", note: "أدخل المفتاح أولاً" });
      return;
    }
    update(p.id, { status: "checking", note: "جاري الفحص…" });
    const r = await fetch("/api/providers/validate", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ kind: p.kind, apiKey: key, baseUrl: p.baseUrl }) });
    const data = await r.json().catch(() => ({}));
    if (data.status === "connected") await saveSecret(p.id, key);
    update(p.id, { status: data.status || "failed", note: data.message || "فشل ❌" });
    onProvidersChange(providers.map(x => x.id === p.id ? { ...x, status: data.status || "failed", note: data.message } : x));
  };

  const addProvider = () => {
    const id = `custom-${crypto.randomUUID()}`;
    const p: ProviderRow = { id, name: "مزود مخصص", kind: "custom", status: "idle" };
    setProviders(old => [...old, p]);
    setOpenId(id);
  };

  const remove = async (p: ProviderRow) => {
    await removeSecret(p.id);
    setProviders(old => old.filter(x => x.id !== p.id));
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/20 p-3 backdrop-blur-sm sm:p-7">
      <div className="mx-auto flex h-full max-w-6xl overflow-hidden rounded-[28px] border border-slate-200 bg-white shadow-2xl">
        <aside className="w-56 shrink-0 border-l border-slate-100 bg-slate-50/70 p-4">
          <button onClick={onClose} className="mb-5 w-full rounded-2xl bg-white px-4 py-3 text-right text-sm font-bold text-slate-700 shadow-sm">رجوع ←</button>
          <nav className="space-y-2">
            <button onClick={() => setSection("providers")} className={`w-full rounded-2xl px-4 py-3 text-right text-sm font-bold ${section === "providers" ? "bg-blue-600 text-white" : "text-slate-600 hover:bg-white"}`}>المزودات والذكاء الاصطناعي</button>
            <button onClick={() => setSection("account")} className={`w-full rounded-2xl px-4 py-3 text-right text-sm font-bold ${section === "account" ? "bg-blue-600 text-white" : "text-slate-600 hover:bg-white"}`}>الحساب وGitHub</button>
            <button onClick={() => setSection("about")} className={`w-full rounded-2xl px-4 py-3 text-right text-sm font-bold ${section === "about" ? "bg-blue-600 text-white" : "text-slate-600 hover:bg-white"}`}>حول الفطنة</button>
          </nav>
        </aside>

        <div className="app-scroll min-w-0 flex-1 overflow-y-auto p-5 sm:p-8">
          {section === "providers" && (
            <div className="mx-auto max-w-3xl">
              <div className="mb-7 flex items-start justify-between gap-4">
                <div><h2 className="text-2xl font-black">المزودات والذكاء الاصطناعي</h2><p className="mt-1 text-sm text-slate-500">المفاتيح تحفظ محلياً داخل متصفحك، بينما كل فحص أو طلب يمر عبر العملية الحالية فقط.</p></div>
                <button onClick={addProvider} className="rounded-2xl bg-slate-950 px-4 py-3 text-sm font-black text-white">+ إضافة 🔑</button>
              </div>
              <div className="space-y-4">
                {providers.map(p => (
                  <div key={p.id} className="rounded-3xl border border-slate-200 bg-white p-4 shadow-sm">
                    <button onClick={() => setOpenId(openId === p.id ? "" : p.id)} className="flex w-full items-center justify-between gap-3 text-right">
                      <div><div className="font-black">{p.name}</div><div className="text-xs text-slate-400">{p.kind === "custom" ? "OpenAI-compatible" : p.kind}</div></div>
                      <div className="flex items-center gap-2"><span className={`h-2.5 w-2.5 rounded-full ${p.status === "connected" ? "bg-emerald-500" : p.status === "needs_balance" ? "bg-amber-500" : p.status === "failed" ? "bg-rose-500" : "bg-slate-300"}`} /><span className="text-xs text-slate-500">{p.status === "connected" ? "متصل ✅" : p.status === "needs_balance" ? "يحتاج إلى رصيد" : p.status === "failed" ? "فشل ❌" : "غير متصل"}</span></div>
                    </button>

                    {openId === p.id && <div className="mt-4 grid gap-3">
                      {p.kind === "custom" && <input value={p.baseUrl || ""} onChange={e => update(p.id, { baseUrl: e.target.value })} placeholder="Base URL مثل https://example.com/v1" className="rounded-2xl border border-slate-200 px-4 py-3 text-left outline-none focus:border-blue-500" dir="ltr" />}
                      <input value={p.key || ""} onChange={e => update(p.id, { key: e.target.value })} placeholder="API Key" type="password" className="rounded-2xl border border-slate-200 px-4 py-3 text-left outline-none focus:border-blue-500" dir="ltr" />
                      <div className="flex flex-wrap gap-2">
                        <button onClick={() => connect(p)} className="rounded-2xl bg-blue-600 px-4 py-3 text-sm font-black text-white">حفظ واتصال</button>
                        {p.kind === "custom" && <button onClick={() => remove(p)} className="rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm font-bold text-rose-600">حذف</button>}
                        <span className="self-center text-xs text-slate-500">{p.note || ""}</span>
                      </div>
                    </div>}
                  </div>
                ))}
              </div>
              <div className="mt-5 rounded-2xl bg-slate-50 p-4 text-xs leading-6 text-slate-500">ملاحظة: حالة "رفض المزود يحتاج إلى رصيد" تشمل حالات الرصيد المنتهي أو rate limit، لأن بعض المزودات تستخدم 429 بدلاً من كود مخصص للرصيد.</div>
            </div>
          )}

          {section === "account" && <div className="mx-auto max-w-3xl"><h2 className="text-2xl font-black">الحساب وGitHub</h2><p className="mt-3 text-sm leading-7 text-slate-500">تسجيل GitHub محفوظ بجلسة HttpOnly على الخادم. إزالة صلاحية التطبيق من GitHub أو تسجيل الخروج ينهي الجلسة.</p></div>}
          {section === "about" && <div className="mx-auto max-w-3xl"><h2 className="text-2xl font-black">حول الفطنة</h2><p className="mt-3 text-sm leading-7 text-slate-500">الفطنة — منصة عربية للدردشة، كتابة الكود، بناء المشاريع، المعاينة، والنشر.</p></div>}
        </div>
      </div>
    </div>
  );
}
