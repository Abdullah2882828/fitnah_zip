const API = "https://api.github.com";
const API_VERSION = "2026-03-10";

async function gh(path: string, token: string, init?: RequestInit) {
  const res = await fetch(`${API}${path}`, {
    ...init,
    headers: {
      accept: "application/vnd.github+json",
      authorization: `Bearer ${token}`,
      "X-GitHub-Api-Version": API_VERSION,
      ...(init?.headers || {})
    },
    cache: "no-store"
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const message = data?.message || `GitHub request failed (${res.status})`;
    throw new Error(message);
  }
  return data;
}

export async function githubMe(token: string) {
  return gh("/user", token);
}

export async function createUserRepo(token: string, args: { name: string; description?: string; private: boolean }) {
  return gh("/user/repos", token, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      name: args.name,
      description: args.description || "Created by الفطنة (Al-Fitnah)",
      private: args.private,
      has_issues: true,
      has_projects: false,
      has_wiki: false,
      auto_init: false
    })
  });
}

export async function createBlob(token: string, owner: string, repo: string, content: string) {
  return gh(`/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/git/blobs`, token, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      content: Buffer.from(content, "utf8").toString("base64"),
      encoding: "base64"
    })
  });
}

export async function getRef(token: string, owner: string, repo: string, ref = "heads/main") {
  return gh(`/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/git/ref/${ref}`, token);
}

export async function getCommit(token: string, owner: string, repo: string, sha: string) {
  return gh(`/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/git/commits/${sha}`, token);
}

export async function createTree(token: string, owner: string, repo: string, baseTree: string | null, tree: Array<{ path: string; mode: string; type: string; sha: string }>) {
  const payload: Record<string, unknown> = { tree };
  if (baseTree) payload.base_tree = baseTree;
  return gh(`/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/git/trees`, token, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(payload)
  });
}

export async function createCommit(token: string, owner: string, repo: string, message: string, tree: string, parents: string[]) {
  return gh(`/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/git/commits`, token, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ message, tree, parents })
  });
}

export async function updateRef(token: string, owner: string, repo: string, ref = "heads/main", sha: string) {
  return gh(`/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/git/refs/${ref}`, token, {
    method: "PATCH",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ sha, force: false })
  });
}
