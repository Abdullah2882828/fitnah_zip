import { cookies } from "next/headers";
import { jwtDecrypt, EncryptJWT } from "jose";

const COOKIE_NAME = process.env.COOKIE_NAME || "al_fitnah_session";
const secret = new TextEncoder().encode(process.env.SESSION_SECRET || "development-secret-change-me");

export type SessionPayload = {
  accessToken: string;
  login: string;
  avatarUrl?: string | null;
  name?: string | null;
};

export async function setSession(payload: SessionPayload) {
  const token = await new EncryptJWT(payload as Record<string, unknown>)
    .setProtectedHeader({ alg: "dir", enc: "A256GCM" })
    .setIssuedAt()
    .setExpirationTime("1y")
    .encrypt(secret);
  const jar = await cookies();
  jar.set(COOKIE_NAME, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 365
  });
}

export async function getSession(): Promise<SessionPayload | null> {
  try {
    const jar = await cookies();
    const token = jar.get(COOKIE_NAME)?.value;
    if (!token) return null;
    const { payload } = await jwtDecrypt(token, secret);
    if (typeof payload.accessToken !== "string" || typeof payload.login !== "string") return null;
    return {
      accessToken: payload.accessToken,
      login: payload.login,
      avatarUrl: typeof payload.avatarUrl === "string" ? payload.avatarUrl : null,
      name: typeof payload.name === "string" ? payload.name : null
    };
  } catch {
    return null;
  }
}

export async function clearSession() {
  const jar = await cookies();
  jar.delete(COOKIE_NAME);
}
