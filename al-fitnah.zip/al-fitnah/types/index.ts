export type ProviderKind = "groq" | "gemini" | "deepseek" | "anthropic" | "custom";

export type ProviderConfig = {
  id: string;
  name: string;
  kind: ProviderKind;
  baseUrl?: string;
  defaultModel?: string;
  key?: string;
};

export type ProviderStatus = "idle" | "checking" | "connected" | "failed" | "needs_balance";

export type ChatMessage = {
  id: string;
  role: "user" | "assistant";
  text: string;
  timestamp: number;
  attachmentNames?: string[];
};

export type ProjectFile = {
  path: string;
  content: string;
};
